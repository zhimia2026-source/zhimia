# ZHIMA Mia Archive Transfer

Copy `.github/workflows/mia-clone-transfer.yml` and
`scripts/mia-clone-transfer.mjs` into the root of
`zhimia2026-source/zhimia`.

## Required GitHub Actions secrets

Repository Settings -> Secrets and variables -> Actions:

- `MIA_SOURCE_SUPABASE_URL` — source API URL for project `dbooikzqprnqbgpfwsze`
- `MIA_SOURCE_SERVICE_ROLE_KEY` — source server-side service-role key
- `ZHIMA_SUPABASE_URL` — target API URL for project `lvxmygrgqtmzqgailmyl`
- `ZHIMA_SUPABASE_SERVICE_ROLE_KEY` — target server-side service-role key

Never paste service-role keys into chat, source files, commits, or browser code.
Use GitHub Actions Secrets only.

## Run

GitHub -> Actions -> "Mia source-to-ZHIMA archive transfer" -> Run workflow.

The workflow is manual only. It reads source tables with GET requests and writes
only to the fixed `mia_private` archive batch through `mia-private-import`.
The import is idempotent on batch/table/source primary key. It strips secret-like
fields server-side. It does not write to Federation, alter the source project,
or activate the target Mia runtime.

A successful archive transfer still requires post-run row-count and checksum
verification. Storage objects, Edge Function code, environment configuration,
and AGNES credentials are separate migration stages.

Batch: `a14c9095-2c72-4d11-80b6-8274cd9bf43c`
Target agent: `34833ba9-2be7-4a55-9b52-62c402f759b5`
